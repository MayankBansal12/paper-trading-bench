import type {
  DecisionContext,
  OhlcvBar,
  PortfolioState,
  RunLimits,
} from "../domain/types.ts";
import { assertDate, exchangeDates, shiftDate } from "../data/calendar.ts";
import { computeIndicators } from "../data/indicators.ts";
import { contentHash } from "../run/persist.ts";

export const STUDY_PROTOCOL = "v8-session-sandbox-journal";
export const STUDY_TOOLS = [
  "get_universe",
  "get_price",
  "get_ohlcv",
  "get_indicators",
  "get_portfolio",
  "buy",
  "sell",
  "journal_append",
  "journal_read",
  "journal_search",
] as const;
export const POLICY = Object.freeze({
  version: STUDY_PROTOCOL,
  maxHistory: 252,
  maxAttemptsPerDay: 3,
  maxEntryChars: 2000,
  maxEntries: 8,
  maxReadChars: 12000,
  maxRequestBytes: 16384,
  maxResponseBytes: 131072,
  maxOutputBytes: 16777216,
  reports: "disabled-technical-only",
  journal: "own-committed-past-and-current-attempt",
});
export interface SessionScope {
  protocol: string;
  runId: string;
  date: string;
  attempt: number;
  observationDate: string;
  reportCutoff: string;
}
export interface SessionView {
  scope: SessionScope;
  universe: readonly string[];
  bars: Record<string, OhlcvBar[]>;
  indicators: DecisionContext["indicators"];
  portfolio: PortfolioState;
  limits: RunLimits;
}
export function scopeFor(
  runId: string,
  date: string,
  attempt: number,
): SessionScope {
  assertDate(date);
  if (
    !/^[a-zA-Z0-9_-]{1,120}$/.test(runId) ||
    !Number.isSafeInteger(attempt) ||
    attempt < 1 ||
    attempt > POLICY.maxAttemptsPerDay
  )
    throw new Error("Invalid session identity");
  if (exchangeDates(date, date).length !== 1)
    throw new Error("Session must be an exchange day");
  const prior = exchangeDates(shiftDate(date, -14), shiftDate(date, -1)).at(-1);
  if (!prior) throw new Error("Missing observation session");
  const month = Math.floor((Number(date.slice(5, 7)) - 1) / 3) * 3 + 1;
  return Object.freeze({
    protocol: STUDY_PROTOCOL,
    runId,
    date,
    attempt,
    observationDate: prior,
    reportCutoff: `${date.slice(0, 4)}-${String(month).padStart(2, "0")}-01`,
  });
}
export function makeView(
  ctx: DecisionContext,
  scope: SessionScope,
): SessionView {
  if (
    ctx.date !== scope.date ||
    contentHash(scope) !==
      contentHash(scopeFor(scope.runId, scope.date, scope.attempt))
  )
    throw new Error("Context/session mismatch");
  if (
    !ctx.universe.length ||
    new Set(ctx.universe).size !== ctx.universe.length
  )
    throw new Error("Invalid universe");
  const bars: SessionView["bars"] = {},
    indicators: SessionView["indicators"] = {};
  for (const ticker of ctx.universe) {
    if (!/^[A-Z][A-Z0-9.-]{0,15}$/.test(ticker))
      throw new Error("Invalid security identity");
    const history = ctx.bars[ticker];
    for (const bar of history ?? []) assertDate(bar.date);
    if (
      !history?.length ||
      history.at(-1)!.date !== scope.observationDate ||
      history.some(
        (b, i) =>
          b.date > scope.observationDate ||
          (i > 0 && b.date <= history[i - 1]!.date) ||
          ![b.open, b.high, b.low, b.close].every(
            (n) => Number.isFinite(n) && n > 0,
          ) ||
          !Number.isFinite(b.volume) ||
          b.volume < 0 ||
          b.low > Math.min(b.open, b.close) ||
          b.high < Math.max(b.open, b.close),
      )
    )
      throw new Error("Invalid or noncausal market snapshot");
    // Indicators and raw observations use the same eligible prefix, never supplied future-derived indicators.
    bars[ticker] = structuredClone(history.slice(-POLICY.maxHistory));
    indicators[ticker] = computeIndicators(bars[ticker]!);
  }
  for (const n of [
    ctx.limits.maxTurns,
    ctx.limits.maxToolCalls,
    ctx.limits.timeoutMs,
  ])
    if (!Number.isSafeInteger(n) || n <= 0) throw new Error("Invalid budget");
  if (
    ctx.limits.maxTurns > 24 ||
    ctx.limits.maxToolCalls > 64 ||
    ctx.limits.timeoutMs > 300000
  )
    throw new Error("Study budget exceeds hard limits");
  if (!Number.isFinite(ctx.portfolio.cash) || ctx.portfolio.cash < 0)
    throw new Error("Invalid portfolio");
  for (const [ticker, h] of Object.entries(ctx.portfolio.holdings))
    if (
      !ctx.universe.includes(ticker) ||
      h.lastClose !== bars[ticker]!.at(-1)!.close
    )
      throw new Error("Portfolio mark is not observable");
  return deepFreeze({
    scope,
    universe: [...ctx.universe],
    bars,
    indicators,
    portfolio: structuredClone(ctx.portfolio),
    limits: { ...ctx.limits },
  });
}
export function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object") {
    Object.freeze(value);
    for (const v of Object.values(value)) deepFreeze(v);
  }
  return value;
}
export const viewHash = (view: SessionView) => contentHash(view);
export function systemPrompt(limits: RunLimits): string {
  return [
    "You manage a long-only fractional-share paper portfolio using supplied historical technical data.",
    "Choose your own securities, sizing, cash retention, concentration, diversification, turnover, and analysis. Buying, selling, holding, and all-cash are all permitted. No particular indicators or tool sequence are required.",
    "The runner sets the simulated session date. Prices are the latest observable PREVIOUS-session closes, labeled with their observation date. Today's opening price is unknown. Orders are queued and execute in order at today's open only after you finish; queued orders never update portfolio tools. A sale can fund only later queued buys. No leverage, shorts, fees, or modeled slippage. Contributions/actions shown by portfolio tools are already applied.",
    "Obtain financial information only through trading tools. No browsing, shell, filesystem, external data, or recalled future information is permitted. Tools accept no price dates. Reports/news are unavailable in this technical-only protocol.",
    "Your journal persists within this run. You may read/search committed past entries and append notes to the current day. Existing entries cannot be edited. After queuing your final orders (or choosing to hold), append a final concise journal entry describing your decision (including holds), supporting evidence, and relevant risks or changes of thesis. Evidence IDs come from tool receipts. Journal notes are your stated rationale, not a request for private chain-of-thought.",
    `Daily limits: ${limits.maxTurns} model turns, ${limits.maxToolCalls} attempted tools, ${limits.timeoutMs}ms. Journal: ${POLICY.maxEntries} entries of ${POLICY.maxEntryChars} characters; reads bounded to ${POLICY.maxReadChars} characters.`,
    "Finish with a concise final decision summary. No calls are allowed after the session ends. A failed, timed-out, or budget-cutoff attempt executes no orders. Trading tool names use the trading_ prefix.",
  ].join("\n");
}
export function dailyPrompt(
  scope: SessionScope,
  start: string,
  end: string,
  contributions: unknown,
): string {
  return `Session date: ${scope.date}. Observable market through: ${scope.observationDate} close. Horizon: ${start} through ${end}. Scheduled contributions: ${JSON.stringify(contributions)}. Read financial state through tools. Journal scope: your own run, committed past and current attempt only. Decide freely and record your decision before finishing.`;
}
